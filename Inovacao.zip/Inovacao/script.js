document.addEventListener('DOMContentLoaded', () => {
  const searchInput = document.getElementById('search-input');
  const optionsContainer = document.getElementById('options-container');
  const flowTitle = document.getElementById('flow-title');

  // Elementos da busca de nós
  const nodeSearchInput = document.getElementById('node-search-input');
  const searchResultsContainer = document.getElementById('search-results-container');

  let searchableNodes = [];     // índice de busca do fluxo atual
  let activeEditor = null;      // instância ativa do Drawflow

  // Lista de arquivos de fluxo
  const flowFiles = ['fluxos/fluxo.json', 'fluxos/fluxo copy.json'];

  let allFlows = [];
  let currentFlows = [];

  // =========================
  // Helpers Drawflow (PAN / CENTRALIZAR)
  // =========================

  /**
   * Move o canvas do Drawflow para (x, y) de forma compatível
   * com versões onde não existe editor.update().
   * Estratégia baseada no padrão conhecido: set canvas_x/canvas_y,
   * aplicar transform no precanvas e chamar zoom_refresh(). [2](https://github.com/jerosoler/Drawflow/issues/88)
   */
  function translateCanvas(editor, x, y) {
    if (!editor) return;

    editor.canvas_x = x;
    editor.canvas_y = y;

    const storedZoom = editor.zoom ?? 1;

    // Aplica transform em zoom=1 (padrão usado para evitar inconsistências)
    editor.zoom = 1;

    if (editor.precanvas) {
      editor.precanvas.style.transform = `translate(${x}px, ${y}px) scale(1)`;
    }

    // Restaura zoom e "refresha"
    editor.zoom = storedZoom;
    editor.zoom_last_value = 1;

    if (typeof editor.zoom_refresh === 'function') {
      editor.zoom_refresh();
    }
  }

  /**
   * Centraliza um nó na viewport.
   * - Considera zoom atual
   * - Usa width/height reais do elemento do nó no DOM (offsetWidth/offsetHeight)
   */
  function centerNode(editor, dfNodeId) {
    if (!editor) return;

    const numericId = Number(dfNodeId);
    const node = editor.getNodeFromId(numericId);
    if (!node) return;

    const container = editor.container;
    const z = editor.zoom ?? 1;

    // Pega o elemento real do nó (Drawflow costuma gerar #node-{id})
    const nodeEl = container.querySelector(`#node-${numericId}`);
    const nodeW = nodeEl?.offsetWidth ?? 250;
    const nodeH = nodeEl?.offsetHeight ?? 150;

    // pos_x/pos_y são coordenadas do canvas base.
    // Para centralizar com zoom, precisamos multiplicar por z.
    const targetX = (container.clientWidth / 2) - (nodeW * z / 2) - (node.pos_x * z);
    const targetY = (container.clientHeight / 2) - (nodeH * z / 2) - (node.pos_y * z);

    translateCanvas(editor, targetX, targetY);
  }

  // =========================
  // 1) Carregar lista de fluxos
  // =========================
  async function loadFlowsList() {
    const flowPromises = flowFiles.map(file =>
      fetch(file)
        .then(res => res.json())
        .then(data => ({
          name: data.data.name || data.data.slug,
          path: file
        }))
        .catch(error => {
          console.error(`Erro ao carregar metadados de ${file}:`, error);
          return null;
        })
    );

    allFlows = (await Promise.all(flowPromises)).filter(Boolean);

    allFlows.sort((a, b) => a.name.localeCompare(b.name));

    currentFlows = allFlows;
    populateOptions(currentFlows);

    // começa escondido
    optionsContainer.classList.add('hidden');
  }

  // =========================
  // 2) Popular opções
  // =========================
  function populateOptions(flows) {
    optionsContainer.innerHTML = '';
    flows.forEach(flow => {
      const optionEl = document.createElement('div');
      optionEl.classList.add('option');
      optionEl.textContent = flow.name;
      optionEl.dataset.path = flow.path;

      optionEl.addEventListener('mousedown', (e) => {
        e.preventDefault();
        searchInput.value = flow.name;
        optionsContainer.classList.add('hidden');
        loadAndRenderFlow(flow.path, flow.name);
      });

      optionsContainer.appendChild(optionEl);
    });
  }

  // =========================
  // 3) Select pesquisável
  // =========================
  searchInput.addEventListener('input', (e) => {
    const filterText = e.target.value.toLowerCase();
    currentFlows = allFlows.filter(flow => flow.name.toLowerCase().includes(filterText));
    populateOptions(currentFlows);
    optionsContainer.classList.remove('hidden');
  });

  searchInput.addEventListener('focus', () => {
    populateOptions(allFlows);
    optionsContainer.classList.remove('hidden');
  });

  document.addEventListener('click', (e) => {
    if (!e.target.closest('.searchable-select')) {
      optionsContainer.classList.add('hidden');
    }
  });

  // =========================
  // 4) Carregar e renderizar fluxo
  // =========================
  function loadAndRenderFlow(filePath, flowName) {
    fetch(filePath)
      .then(response => response.json())
      .then(flowData => {
        if (flowTitle && flowName) {
          flowTitle.textContent = `Fluxo: ${flowName}`;
        }
        renderFlowWithDrawflow(flowData.data);
      })
      .catch(error => console.error(`Erro ao carregar o arquivo ${filePath}:`, error));
  }

  // =========================
  // 5) Busca de nós
  // =========================
  function setupNodeSearch() {
    if (!nodeSearchInput) return;

    nodeSearchInput.addEventListener('input', (e) => {
      const searchTerm = e.target.value.toLowerCase();
      console.log(`Buscando por: "${searchTerm}"`);

      if (searchTerm.length < 2) {
        searchResultsContainer.innerHTML = '';
        return;
      }

      const results = searchableNodes.filter(node => node.text.includes(searchTerm));
      console.log("Resultados da busca:", results, "Editor ativo:", activeEditor);

      renderSearchResults(results, activeEditor);
    });
  }

  function renderSearchResults(results, editor) {
    searchResultsContainer.innerHTML = '';

    if (!editor) {
      searchResultsContainer.innerHTML =
        '<div class="search-result-item">Carregue um fluxo para habilitar a busca.</div>';
      return;
    }

    if (results.length === 0) {
      searchResultsContainer.innerHTML =
        '<div class="search-result-item">Nenhum resultado encontrado.</div>';
      return;
    }

    results.forEach(nodeIndex => {
      const item = document.createElement('div');
      item.className = 'search-result-item';
      item.textContent = nodeIndex.name;
      item.dataset.nodeId = nodeIndex.dfId;

      item.addEventListener('click', () => {
        const dfNodeId = item.dataset.nodeId;

        // Centraliza o nó (sem editor.update()) [2](https://github.com/jerosoler/Drawflow/issues/88)
        centerNode(editor, dfNodeId);

        // Destaque visual usando o elemento real do DOM
        const nodeEl = editor.container.querySelector(`#node-${Number(dfNodeId)}`);
        if (nodeEl) {
          nodeEl.classList.add('node-highlight');
          setTimeout(() => nodeEl.classList.remove('node-highlight'), 1500);
        }
      });

      searchResultsContainer.appendChild(item);
    });
  }

  // =========================
  // Inicialização
  // =========================
  loadFlowsList();
  setupNodeSearch();

  // =========================
  // Renderização do fluxo com Drawflow
  // =========================
  function renderFlowWithDrawflow(data) {
    const container = document.getElementById('drawflow');
    container.innerHTML = '';

    const editor = new Drawflow(container);
    activeEditor = editor;
    editor.start();

    // Evita acumular múltiplos listeners a cada render de fluxo
    if (window._drawflowMouseUpHandler) {
      window.removeEventListener('mouseup', window._drawflowMouseUpHandler);
    }
    window._drawflowMouseUpHandler = (e) => editor.dragEnd(e);
    window.addEventListener('mouseup', window._drawflowMouseUpHandler);

    editor.editor_mode = 'edit';
    editor.reroute = true;

    const nodePositions = data.nodePositionsV2;
    const nodeIdMap = {};
    const localSearchableNodes = [];

    // 1. Limites do fluxo para normalizar posições
    let minX = Infinity;
    let minY = Infinity;
    let maxX = -Infinity;
    let maxY = -Infinity;

    const PADDING = 100;

    for (const nodeId in nodePositions) {
      const pos = nodePositions[nodeId];
      if (pos.x < minX) minX = pos.x;
      if (pos.y < minY) minY = pos.y;
      if (pos.x > maxX) maxX = pos.x;
      if (pos.y > maxY) maxY = pos.y;
    }

    const offsetX = minX < 0 ? -minX + PADDING : PADDING;
    const offsetY = minY < 0 ? -minY + PADDING : PADDING;

    // 2. Adiciona nós
    for (const nodeId in nodePositions) {
      const nodeData = findNodeData(nodeId, data);

      const originalPos = nodePositions[nodeId];
      const correctedPosX = originalPos.x + offsetX;
      const correctedPosY = originalPos.y + offsetY;

      // Nó start
      if (nodeId === 'start') {
        const startContent = `
          <div class="node-header">Início do Fluxo</div>
          <div class="node-name">Start</div>
        `;
        const drawflowNodeId = editor.addNode(
          'start', 0, 1, correctedPosX, correctedPosY, 'node-start', { id: 'start' }, startContent, false
        );
        nodeIdMap['start'] = { dfId: drawflowNodeId, outputs: { 'default': 1 } };
        continue;
      }

      // Nós de condição
      if (nodeId.startsWith('--condition--')) {
        if (nodeData) {
          const rule = nodeData.rules?.[0];
          const conditionText = rule
            ? `${rule.variableKey} ${rule.expressionLabel} ${rule.expressionTest}`
            : 'Condição';

          const content = `
            <div class="node-header">Condição</div>
            <div class="node-name" contenteditable="true">${nodeData.name || 'Condição sem nome'}</div>
            <div class="node-id">IF: ${conditionText}</div>
          `;

          const outputs = getOutputsForNode(nodeId, nodeData, data.edges);

          const drawflowNodeId = editor.addNode(
            nodeId,
            1,
            Object.keys(outputs).length || 1,
            correctedPosX,
            correctedPosY,
            'node-condition',
            { id: nodeId },
            content,
            false
          );

          nodeIdMap[nodeId] = { dfId: drawflowNodeId, outputs };
        }
        continue;
      }

      if (!nodeData) {
        console.warn(`Dados do nó não encontrados para o ID: ${nodeId}`);
        continue;
      }

      let nodeTypeLabel = '';
      let nodeName = '';
      let nodeTypeForClass = '';

      if (nodeId.startsWith('--stepaction--')) {
        const action = nodeData.actions?.[0] || {};
        nodeTypeLabel = `Ação: ${action.type || 'unknown'}`;
        nodeTypeForClass = action.type || 'unknown';
        nodeName = nodeData.name || action.func || action.trigger || action.actionName || 'Ação sem nome';
      } else {
        nodeTypeLabel = `Passo: ${nodeData.type}`;
        nodeTypeForClass = nodeData.type;
        nodeName = nodeData.name;
      }

      let nodeClass = `type-${nodeTypeForClass}`;
      if (nodeId === data.start) nodeClass += ' node-start';

      // Conteúdo extra para nós text
      let textContentHtml = '';
      let textContentForSearch = '';

      const rawText = nodeData.promptsV2?.yellowmessenger?.[0]?.messages?.[0]?.value;
      if (nodeData.type === 'text' && rawText) {
        const cleanedText = rawText.replace(/\{\{\{.*?\}\}\}/g, '[variável]');
        textContentHtml = `<div class="node-text-content">${cleanedText}</div>`;
        textContentForSearch = cleanedText;
      }

      const content = `
        <div class="node-header">${nodeTypeLabel}</div>
        <div class="node-name" contenteditable="true">${nodeName}</div>
        ${textContentHtml}
        <div class="node-id">ID: ${nodeId}</div>
      `;

      const outputs = getOutputsForNode(nodeId, nodeData, data.edges);

      const drawflowNodeId = editor.addNode(
        nodeId,
        1,
        Object.keys(outputs).length || 1,
        correctedPosX,
        correctedPosY,
        nodeClass,
        { id: nodeId },
        content,
        false
      );

      localSearchableNodes.push({
        id: nodeId,
        dfId: drawflowNodeId,
        name: nodeName,
        text: `${nodeTypeLabel} ${nodeName} ${textContentForSearch} ${nodeId}`.toLowerCase()
      });

      nodeIdMap[nodeId] = { dfId: drawflowNodeId, outputs };
    }

    // 3. Conexões
    for (const edgeId in data.edges) {
      const edge = data.edges[edgeId];
      const sourceId = edge.source.split('##')[0];
      const sourceOutputKey = edge.source.split('##')[1] || 'default';
      const targetId = edge.target;

      const sourceNodeInfo = nodeIdMap[sourceId];
      const targetNodeInfo = nodeIdMap[targetId];

      if (sourceNodeInfo && targetNodeInfo) {
        const outputIndex = sourceNodeInfo.outputs[sourceOutputKey] || 1;
        editor.addConnection(
          sourceNodeInfo.dfId,
          targetNodeInfo.dfId,
          `output_${outputIndex}`,
          'input_1'
        );
      }
    }

    // 4. Zoom to fit (se existir)
    if (typeof editor.zoom_to_fit === 'function') {
      editor.zoom_to_fit();
    }

    console.log("Nós indexados para busca:", localSearchableNodes);
    searchableNodes = localSearchableNodes;
  }

  // =========================
  // Helpers do seu modelo de dados
  // =========================
  function findNodeData(nodeId, data) {
    if (nodeId.startsWith('--stepaction--')) {
      return data.stepActionNodes?.[nodeId.replace('--stepaction--', '')];
    }
    if (nodeId.startsWith('--condition--')) {
      return data.conditionalNodes?.[nodeId.replace('--condition--', '')];
    }
    return data.steps?.[nodeId];
  }

  function getOutputsForNode(nodeId, nodeData, allEdges) {
    const outputs = {};
    let outputIndex = 1;

    for (const edgeId in allEdges) {
      if (allEdges[edgeId].source.startsWith(nodeId + '##')) {
        const outputKey = allEdges[edgeId].source.split('##')[1];
        if (!outputs[outputKey]) {
          outputs[outputKey] = outputIndex++;
        }
      }
    }

    if (nodeData?.rules) {
      nodeData.rules.forEach(rule => {
        if (!outputs[rule.id]) outputs[rule.id] = outputIndex++;
      });
    }

    if (nodeData?.next && !outputs['default']) {
      outputs['default'] = 1;
    }

    return outputs;
  }
});
``